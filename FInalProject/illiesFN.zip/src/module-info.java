module FInalProject {
    requires javafx.fxml;
    requires javafx.controls;
    requires json.simple;
    requires java.sql;
    opens sample;
}